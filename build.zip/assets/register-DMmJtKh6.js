import{j as e}from"./index-dHECfXoj.js";const t=()=>e.jsx("div",{children:"Register"});export{t as default};

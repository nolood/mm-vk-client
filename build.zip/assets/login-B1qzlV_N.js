import{j as o}from"./index-dHECfXoj.js";const t=()=>o.jsx("div",{children:"login"});export{t as default};

import{j as r}from"./index-dHECfXoj.js";const i=()=>r.jsx("div",{children:"Main"});export{i as default};
